<header>
  <link rel="stylesheet" href="headerStyles.css">
  <div class="all">
    <div class=upperHeader>
      <img src="https://i.pinimg.com/736x/b1/97/da/b197daf5f1cc7abf4948611468b6f745.jpg">
      <h1>FOODICTED</h1>
    </div>
    <nav class="nav">
      <ul>
        <li><a href="homepage.php">Home</a></li>
        <li><a href="aboutUs.php">About Us</a></li>
        <li><a href="recipespage.php">Recipes</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a href="login.php">Login</a></li>
        <li><a href="register.php">Sign up</a></li>
      </ul>
    </nav>
  </div>
</header>
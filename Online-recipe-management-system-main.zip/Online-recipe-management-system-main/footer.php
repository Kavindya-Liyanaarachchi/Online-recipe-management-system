<footer>
  <link rel="stylesheet" href="footerStyles.css">
  <section>
    <ul>
      <li class="text-box">FOODICTED</li>
      <li><a href="">FOLLOW US ON SOCIAL MEDIA </a></li>
      <div class="icons">
        <img src="https://assets.website-files.com/5e87da28516d8f3eaaabbb9c/5e8e47efd6781da92747ac29_facebook.svg" alt="fb" />
        <img src="https://assets.website-files.com/5e87da28516d8f3eaaabbb9c/5e8e5e3951d8bbb736263092_instagram%20(1).svg" alt="insta" />
        <img src="https://assets.website-files.com/5e87da28516d8f3eaaabbb9c/5e93bf0eefc8a008e85f0187_twitter%20(1).svg" alt="x" />
      </div>
    </ul>
  </section>

  <section class="imgs">
    <img src="https://i.pinimg.com/736x/05/ce/a9/05cea9c0f6145a493e8932ac7bad2890.jpg">
  </section>
  <section>
    <ul>
      <li><a href="">F&Qs</a></li>
      <li><a href="">CONTACT US</a></li>
      <li><a href="aboutUs.php">ABOUT US</a></li>
    </ul>
  </section>
  <section>
    <ul>
      <p class="text-box">GET THE FRESHEST FOODICTED NEWS</p>
      <p><input type="text" id="recipient-email" name="recipient-email" value="Enter your email address"></p>
    </ul>
  </section>

</footer>